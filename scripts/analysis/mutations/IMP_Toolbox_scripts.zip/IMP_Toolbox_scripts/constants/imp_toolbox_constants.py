from enum import StrEnum, auto
from dataclasses import dataclass
from string import Template

MAX_API_RETRIES = 3
CHIMERAX_RUN_CMD = "flatpak run edu.ucsf.rbvi.ChimeraX"

class MiscStrEnum(StrEnum):
    """
    Enum for miscellaneous string constants.
    """
    LOWER = auto()
    UPPER = auto()
    TRUE = auto()
    FALSE = auto()
    NUM_PTS = auto()
    MODEL_MRC = auto()
    REF_MRC = auto()
    SAMPLE_A = "Sample_A"
    SAMPLE_B = "Sample_B"
    NUM_GAUSSIANS = auto()

class FileFormat(StrEnum):
    """
    Enum for supported file formats.
    """
    FASTA = auto()
    FA = auto()
    PDB = auto()
    CIF = auto()
    MRC = auto()
    TXT = auto()
    HTML = auto()

@dataclass
class APIurl:

    uniprot_rest_api = "https://rest.uniprot.org/"
    uniprot_rest_api_sequence = Template(
        f"{uniprot_rest_api}" +
        "/uniprotkb/accessions?accessions=${ids}&format=fasta"
    )

    pdbe_graph_api = "https://www.ebi.ac.uk/pdbe/graph-api"
    pdbe_api_best_structures = Template(
        f"{pdbe_graph_api}" +
        "/mappings/best_structures/${uniprot_id}"
    )

    emdb_ftp = "https://ftp.ebi.ac.uk/pub/databases/emdb"
    emdb_ftp_map = Template(
        f"{emdb_ftp}/structures" +
        "/${emdb_id_hyphen}/map/${emdb_id_underscore}.map.gz"
    )
    emdb_ftp_mask = Template(
        f"{emdb_ftp}/structures" +
        "/${emdb_id_hyphen}/masks/${mask_name}.map"
    )

class MRCComparisonMode(StrEnum):
    PASANI = auto()
    CHIMERAX = auto()

CLUSTER_MRC_PREFIX = "LPD"

class CorrelationMetric(StrEnum):
    """
    Enum for supported correlation metrics for fitting GMMs to density maps.
    """
    CAM = auto()
    CORRELATION = auto()
    OVERLAP = auto()

@dataclass
class ChimeraXDefaults:

    correlation_metric: str | CorrelationMetric = CorrelationMetric.OVERLAP
    envelop_val: str | MiscStrEnum = MiscStrEnum.TRUE
    shift_val: str | MiscStrEnum = MiscStrEnum.TRUE
    rotate_val: str | MiscStrEnum = MiscStrEnum.TRUE
    zeros_val: str | MiscStrEnum = MiscStrEnum.FALSE
    fitmap_max_steps: int = 2000

class ChimeraXVolumeLevelType(StrEnum):
    """
    Enum for supported volume thresholding level types in ChimeraX.
    """
    LEVEL = "level"
    SD_LEVEL = "sdLevel"
    RMS_LEVEL = "rmsLevel"

class ChimeraXCommand(StrEnum):
    """
    Enum for supported ChimeraX command names.
    """
    FITMAP = auto()
    MEASURE_CORRELATION = "measure correlation"
    OPEN = auto()
    CLOSE = auto()
    VOLUME = auto()
    VOLUME_THRESHOLD = auto()
    VOLUME_ADD = f"{VOLUME} add"
    RENAME = auto()

CHIMERAX_COMMANDS: dict[ChimeraXCommand, str | Template] = {
    ChimeraXCommand.FITMAP: Template(
        "fitmap ${model_idxs} " +
        "inmap ${ref_idxs} " +
        "metric ${metric} " +
        "shift ${shift_val} " +
        "rotate ${rotate_val} " +
        "envelope ${envelop_val} " +
        "maxSteps ${fitmap_max_steps} " +
        "zeros ${zeros_val}"
    ),
    ChimeraXCommand.MEASURE_CORRELATION: Template(
        "measure correlation ${model_idxs} " +
        "in_map ${ref_idxs} " +
        "envelope ${envelop_val}"
    ),
    ChimeraXCommand.OPEN: Template("open ${file_path}"),
    ChimeraXCommand.CLOSE: Template("close ${model_idxs}"),
    ChimeraXCommand.VOLUME_THRESHOLD: Template(
        "volume ${model_idxs} ${level_type} ${level_val}"
    ),
    ChimeraXCommand.VOLUME_ADD: Template(
        "volume add ${model_range}"
    ),
    ChimeraXCommand.RENAME: Template(
        "rename ${model_idx} ${new_name}"
    )
}

CHIMERAX_LOG_PATTERNS: dict[ChimeraXCommand, dict] = {

    ChimeraXCommand.FITMAP: {
        "look_for": "Fit map",
        "regex1": r"Fit map (.+) in map (.+) using (\d+) points",
        "regex2": r"correlation = ([0-9]*\.?[0-9]+), correlation about mean = ([0-9]*\.?[0-9]+), overlap = ([0-9]*\.?[0-9]+)"
    },

    ChimeraXCommand.MEASURE_CORRELATION: {
        "look_for": "Correlation of",
        "regex1": r"Correlation of (\S+) #(\d+) above level ([0-9.]+e[+-]?[0-9]+) in (\S+) #(\d+)",
        "regex2": r"correlation = ([0-9]*\.?[0-9]+), correlation about mean = ([0-9]*\.?[0-9]+)"
    }
}

@dataclass
class GMMParams:
    """
    Dataclass for GMM parameters.
    """
    threshold: float = 0.95
    correlation_metric : str | CorrelationMetric = CorrelationMetric.CAM
    gmm_mrc_name = Template("${f_name}_${n_gaussian}")
    log_file_name = Template("${f_name}_gmm_selection_log_chimerax")